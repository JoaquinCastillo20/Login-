--- 19-08-2022 19:16:28
--- SQLite
DROP TABLE demo;

--- 19-08-2022 19:16:57
--- SQLite
CREATE TABLE Usuarios (
  Usuario VARCHAR (20) not NULL,
  Clave VARCHAR (20) not NULL);

--- 19-08-2022 19:17:23
--- SQLite
INSERT INTO Usuarios (usuario,clave) VALUES ("Sofia", "12345");

--- 19-08-2022 19:17:41
--- SQLite
INSERT INTO Usuarios (usuario,clave) VALUES ("Joaquin", "6789");

--- 19-08-2022 19:18:00
--- SQLite
INSERT INTO Usuarios (usuario,clave) VALUES ("Rami", "1359");

--- 19-08-2022 19:18:13
--- SQLite
INSERT INTO Usuarios (usuario,clave) VALUES ("Lucho", "4892");

--- 19-08-2022 19:18:33
--- SQLite
SELECT * FROM Usuarios;

