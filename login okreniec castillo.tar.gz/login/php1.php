<?php
  $Usuario = $_POST['Usuario'];
  $Clave = $_POST['Clave'];

  $enlace = mysqli_connect($direccion, $Usuario, $Clave, $Usuarios);
  $consulta = "SELECT * FROM Usuarios";
  $resultado = mysqli_query($enlace, $consulta);
 ?>
